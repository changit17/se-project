  

  <table class="table table-striped" bgcolor="#fff">

  <td>
<a href="department_list.php"  class="btn btn-danger btn-m"><i class="fa fa-fw fa-table"></i>Department Table</a>
</td>


<td>
<a href="index.php"  class="btn btn-info btn-m"><i class="fa fa-fw fa-user"></i>Student Table</a>
</td>

<td>
<a href="course.php"  class="btn btn-success btn-m"><i class="fa fa-fw fa-table"></i>Section Table</a>
</td>

<td>
<a href="course.php"  class="btn btn-primary btn-m"><i class="fa fa-fw fa-table"></i>Course Table</a>
</td>


<td>
<a href="section.php"  class="btn btn-warning btn-m"><i class="fa fa-fw fa-table"></i>Section Table</a>
</td>
<td>
<a href="subject_list.php"  class="btn btn-success btn-m"><i class="fa fa-fw fa-table"></i>Subject Table</a>
</td>


</table>