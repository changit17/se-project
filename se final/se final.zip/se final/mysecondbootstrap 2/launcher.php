



<!DOCTYPE html>

<title></title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">



<body>
	

					
			

<!-- Title -->



	<?php include('launch-modal.php');?>
	
	<script src="js/jquery.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>

</body>


</html>
