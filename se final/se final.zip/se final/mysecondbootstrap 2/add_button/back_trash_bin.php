<!-- Title -->
<h1><i class="fa fa-fw fa-trash"></i>Student Table</h1>


<!-- Button trigger modal -->
<p>
<a href="index.php" class="btn btn-warning btn-m" >
  <i class="fa fa-fw fa-check"></i>BACK
</a>

</p>