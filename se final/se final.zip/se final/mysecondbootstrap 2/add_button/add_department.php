<!-- Title -->
<h1><i class="fa fa-fw fa-table"></i>Department Table</h1>


<!-- Button trigger modal -->
<p>
<button type="button" class="btn btn-primary btn-m" data-toggle="modal" data-target="#AddDept">
  <i class="fa fa-fw fa-plus"></i>ADD
</button>


<a href="trash_bin_dept.php" class="btn btn-success btn-m" >
  <i class="fa fa-fw fa-trash"></i>Recycle Bin
</a>
</p>
</p>
