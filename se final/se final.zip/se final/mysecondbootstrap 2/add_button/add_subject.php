<!-- Title -->
<h1><i class="fa fa-fw fa-table"></i>Subject Table</h1>


<!-- Button trigger modal -->
<p>
<button type="button" class="btn btn-primary btn-m" data-toggle="modal" data-target="#AddSubj">
  <i class="fa fa-fw fa-plus"></i>ADD
</button>
</p>
