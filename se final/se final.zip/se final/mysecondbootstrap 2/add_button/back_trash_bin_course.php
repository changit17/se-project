<!-- Title -->
<h1><i class="fa fa-fw fa-trash"></i>Course Table</h1>


<!-- Button trigger modal -->
<p>
<a href="course.php" class="btn btn-warning btn-m" >
  <i class="fa fa-fw fa-check"></i>BACK
</a>

</p>