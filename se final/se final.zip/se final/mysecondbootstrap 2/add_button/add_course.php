<!-- Title -->
<h1><i class="fa fa-fw fa-table"></i>Course Table</h1>


<!-- Button trigger modal -->
<p>
<button type="button" class="btn btn-primary btn-m" data-toggle="modal" data-target="#AddCourse">
    <i class="fa fa-fw fa-plus"></i>ADD
</button>

<a href="trash_bin_course.php" class="btn btn-success btn-m" >
  <i class="fa fa-fw fa-trash"></i>Recycle Bin
</a>
</p>
