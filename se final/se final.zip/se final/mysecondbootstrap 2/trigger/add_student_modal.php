<!-- Title -->
<h1>Student Table</h1>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#AddStud">
  ADD
</button>
