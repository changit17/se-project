<!-- Title -->
<h1>Department Table</h1>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#AddDept">
  ADD
</button>
