<!-- Title -->
<h1>Course Table</h1>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#AddCourse">
  ADD
</button>
