<!-- Title -->
<h1>Subject Table</h1>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#AddSubj">
  ADD
</button>
