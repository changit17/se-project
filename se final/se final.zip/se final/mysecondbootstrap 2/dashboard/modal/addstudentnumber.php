<script type="bootstrap/js/bootstrap.js"></script>
<script type="bootstrap/js/bootstrap.min.js"></script>
<script type="bootstrap/js/npm.js"></script>
<script type="js.js"></script>
<link href="body/bootstrap.css" rel="stylesheet">
<link href="body/bootstrap.min.css" rel="stylesheet">




<!-- Modal -->

  <!--SECTION SECTION -->
   <form method="post">  
  <div class="modal fade" id="AddStu" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Add Student Number</h4>
        </div>
        <div class="modal-body">
        <div class="form-group">

      <label class='control-label' for="su_name">Student Number</label>
      <input type="number" class="form-control" name="s_id" required maxlength="4">
    </div>      
    </div>

        <div class="modal-footer">
    <button type="submit" class="btn btn-primary" name ="submit_Stu">Add</button>  
 
  </div>
  </div>
</div>
</div>
  </form>
  <!--SECTION SECTION-->


    <script src="js/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>